// ai/scripts/analytics.mjs
console.log('[analytics] placeholder: collect basic metrics and write ai/logs/analytics.jsonl');
process.exit(0);
