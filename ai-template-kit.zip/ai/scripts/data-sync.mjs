// ai/scripts/data-sync.mjs
console.log('[data] placeholder: normalize src/_data and emit caches. Exit 0.');
process.exit(0);
