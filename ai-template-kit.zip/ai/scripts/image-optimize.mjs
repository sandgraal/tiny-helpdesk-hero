// ai/scripts/image-optimize.mjs
console.log('[image] placeholder: add your image pipeline here (sharp/squoosh). Exit 0.');
process.exit(0);
