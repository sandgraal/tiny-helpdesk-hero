// ai/scripts/package-render.mjs
console.log('[packaging] placeholder: render labels or PDFs. Exit 0.');
process.exit(0);
